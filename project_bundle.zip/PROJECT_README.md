# Tamweel Lite | مشروعك النهائي

## الملخص التنفيذي
اخترت Logistic Regression كنموذج نهائي (KEEP SINGLE)، لأنه حقق أعلى AP = 0.392 على nested forward OOF، ولم يتفوق عليه أي تجميع بفرق أكبر من الـ fold SD = 0.030. عتبة المراجعة المعايرة 0.1223 تحت سعة 12%: على 2,500 طلب challenge رُفعت 300 إشارة وحُذفت 30 بسبب السقف. فجوة FPR بين المناطق حوالي 4 نقاط مئوية وتحتاج مراجعة. النموذج تعليمي على بيانات اصطناعية، ويحتاج مراقبة للانجراف والسعة والمعايرة، وليس لقرارات تمويل حقيقية.

## Executive summary
I kept a single Logistic Regression model (KEEP SINGLE). It had the highest nested forward OOF AP (0.392, fold SD 0.030), and no ensemble beat it by more than one fold SD (Weighted 0.389, Stack 0.383, Equal 0.372), so the extra complexity was not justified. The calibrated review threshold is 0.1223 under a 12% capacity cap: on the 2,500 challenge requests, 330 exceeded the threshold and the cap kept 300 flags (30 removed). The regional FPR gap was about 4 percentage points and needs review. This is an educational model on synthetic data, not for real financing decisions, and it requires drift, capacity, calibration and regional monitoring.

Decision: KEEP SINGLE / Logistic. Full-batch flags: 300/2500.

اقرأ reports/MODEL_CARD.md والسياسة في artifacts/final_policy.json. الحزمة للتدريب؛ ليست نتيجة تقييم نهائية أو إثبات تسليم. ادمج أدلة أيامك السابقة واحفظ الدفتر المنفذ والعرض.
